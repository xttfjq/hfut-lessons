#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <climits>
#include <cstdio>
using namespace std;
typedef long long ll;

// ---------- ����߽ṹ ----------
struct Edge {
    int to;     // Ŀ��ڵ�
    int rev;    // �������Ŀ��ڵ������
    ll cap;     // ����
    Edge(int _to, int _rev, ll _cap) : to(_to), rev(_rev), cap(_cap) {}
};

// ---------- ȫ�ֱ��� ----------
vector<vector<Edge> > g;  // ͼ���ڽӱ�
vector<int> level;       // BFS �ֲ�ͼ
vector<int> iter;        // ��ǰ���Ż�

// ---------- ���ӱ� ----------
void add_edge(int from, int to, ll cap) {
    g[from].push_back(Edge(to, g[to].size(), cap));
    g[to].push_back(Edge(from, g[from].size() - 1, 0));
}

// ---------- BFS �����ֲ�ͼ ----------
void bfs(int s) {
    fill(level.begin(), level.end(), -1);
    queue<int> q;
    level[s] = 0;
    q.push(s);
    while (!q.empty()) {
        int v = q.front(); q.pop();
        //
        for (int i = 0; i < g[v].size(); i++) {
            Edge& e = g[v][i];
            if (e.cap > 0 && level[e.to] < 0) {
                level[e.to] = level[v] + 1;
                q.push(e.to);
            }
        }
    }
}

// ---------- DFS Ѱ������·�� ----------
ll dfs(int v, int t, ll f) {
    if (v == t) return f;
    for (int& i = iter[v]; i < g[v].size(); i++) {
        Edge& e = g[v][i];
        if (e.cap > 0 && level[v] < level[e.to]) {
            ll d = dfs(e.to, t, min(f, e.cap));
            if (d > 0) {
                e.cap -= d;
                g[e.to][e.rev].cap += d;
                return d;
            }
        }
    }
    return 0;
}

// ---------- Dinic ����� ----------
ll max_flow(int s, int t) {
    ll flow = 0, f;
    while (true) {
        bfs(s);
        if (level[t] < 0) return flow;  // �޷�������
        fill(iter.begin(), iter.end(), 0);
        while ((f = dfs(s, t, LLONG_MAX)) > 0)
            flow += f;
    }
}

// ---------- ������ ----------
int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);  // 

    int N, M;
    cin >> N >> M;             // ����ڵ��� N �ͱ��� M

    g.assign(N + 1, vector<Edge>());
    level.assign(N + 1, -1);
    iter.assign(N + 1, 0);

    for (int i = 0; i < M; i++) {
        int u, v;
        ll cap;
        cin >> u >> v >> cap;  // �������Ϣ
        cout << "�� " << i << ": " << u << "->" << v << " ����=" << cap << endl;
        add_edge(u, v, cap);
    }

    cout << max_flow(1, N) << "\n";  // ��������
    return 0;
}
